namespace Domain;

public class Customers
{
}
