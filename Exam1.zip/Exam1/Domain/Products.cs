namespace Domain;

public class Products
{

}
