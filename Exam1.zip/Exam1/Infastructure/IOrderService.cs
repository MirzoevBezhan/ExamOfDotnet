namespace Infastructure;

public interface IOrderService
{
}
