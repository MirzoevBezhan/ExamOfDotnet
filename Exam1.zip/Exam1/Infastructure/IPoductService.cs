namespace Infastructure;

public class IPoductService
{

}
