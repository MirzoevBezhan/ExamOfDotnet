namespace Infastructure;

public class ICustomerService
{
}
