namespace Infastructure;

public interface ICustomerService
{
}
